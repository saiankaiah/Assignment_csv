import assignment
import unittest



class Testcsvdata(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        print('setupClass')
        
    @classmethod
    def tearDownClass(cls):
        print('teardownClass')
        
    def setUp(self):
        print('setUp')
        self.data = {'date': 'Oct 1 2019', 'type': 'remove', 'amount': '99.10', 'from': '198', 'to': '182'}
        self.expected = {'date': 'Oct 1 2019', 'type': 'remove', 'amount': '99.10', 'from': '198', 'to': '182'}

    def tearDown(self):
        print('tearDown\n')
        
    def test_column_names_with_no_change(self):
        print('test_column_names_with_no_change')
        assignment.final_columns(self.data)
        self.assertEqual(self.data, self.expected)
        
    def test_column_names_with_change(self):
        print('test_column_names_with_change')
        self.data = {'timestamp': 'Oct 1 2019', 'type': 'remove', 'amount': '99.10', 'from': '198', 'to': '182'}
        self.expected = {'date': 'Oct 1 2019', 'type': 'remove', 'amount': '99.10', 'from': '198', 'to': '182'}
        assignment.final_columns(self.data)
        self.assertEqual(self.data, self.expected)
        
    def test_column_names_with_normalize_amount(self):
        print('test_column_names_with_normalize_amount')
        self.data = {'date_readable': '5 Oct 2019', 'type': 'remove', 'euro': '5', 'cents': '44', 'to': '182', 'from': '198'}
        self.expected = {'date': '5 Oct 2019', 'type': 'remove', 'amount': 5.44, 'to': '182', 'from': '198'}
        assignment.final_columns(self.data)
        self.assertEqual(self.data, self.expected)
        
    def test_column_names_with_normalize_date(self):
        print('test_column_names_with_normalize_date')
        self.data = {'date': 'Oct 1 2019', 'type': 'remove', 'amount': '99.10', 'from': '198', 'to': '182'}
        self.expected = {'date': '01/10/19', 'type': 'remove', 'amount': '99.10', 'to': '182', 'from': '198'}
        assignment.normalize_date(self.data)
        self.assertEqual(self.data, self.expected)
        
if __name__ == '__main__':
    unittest.main()    

