import csv
from datetime import datetime 
import os

def final_columns(row):
    columns_dict = {'transaction': 'type', 'amounts': 'amount', 'date_readable': 'date', 'timestamp': 'date', 'transaction_amount':'amount'}
    for old_column, new_column in columns_dict.items():
        if old_column in row:
            row[new_column] = row[old_column]
            del row[old_column]
    if 'euro' in row:
        row['amount'] = int(row['euro']) + (int(row['cents']) / 100)
        del row['euro']
        del row['cents']
        
def normalize_date(row):
    frmts = ['%d-%m-%Y', '%b %d %Y', "%d %b %Y", '%d/%m/%y','%B %d, %Y','%B %d %Y']
    for frmt in frmts:
        try:
            date = datetime.strptime(row['date'], frmt)
            row['date'] = date.strftime("%d/%m/%y")
            break
        except ValueError:
            pass

def read_csv(filename):
    with open(filename, newline='') as csv_file:
        csv_reader = csv.DictReader(csv_file)
        for each_row in csv_reader:
            final_columns(each_row)
            normalize_date(each_row)
            yield each_row

def parse_csv_data(filespath):
    files = [os.path.join(filespath, file) for file in os.listdir(filespath) if file.endswith('.csv')]
    with open('consolidatedFile.csv', 'w') as mergedfile:
        fieldnames=['date', 'type', 'amount', 'to', 'from']
        csv_writer = csv.DictWriter(
            mergedfile, fieldnames=fieldnames)
        csv_writer.writeheader()
        [[csv_writer.writerow(row) for row in each_row] for each_row in [read_csv(file) for file in files]]
        
if __name__ == '__main__':        
    filespath = './csv_files'
    parse_csv_data(filespath)